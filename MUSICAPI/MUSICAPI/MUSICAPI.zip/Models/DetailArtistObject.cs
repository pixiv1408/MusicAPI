﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MUSICAPI.Models
{
    public class DetailArtistObject
    {
        public int? DetailArtistId { get; set; }

        public string ArtistName { get; set; }

        public string GenreName { get; set; }
    }
}
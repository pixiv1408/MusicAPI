﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MUSICAPI.Models
{
    public class SignUpObject
    {
        
        public string UserPhone { get; set; }

    
        public string UserPassword { get; set; }

        
        public string UserName { get; set; }
    }
}